<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>SAVORA | Home Page</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styleN.css">
</head>
<body>
  <header class="mainheader">
      <a href="http://savora.infinityfreeapp.com/SAVORA/index.php">
        <img src="image/logo.png" alt="Savora Logo" class="logo">
    </a>
    <h1 class="Savora-name">SAVORA</h1>
  </header>

  <main class="home-main">
    <div class="home-card">
      <h2>Welcome to Savora</h2>

      <a href="login.php" class="primary-btn">Log In</a>

      <p class="muted-text">
        New User?
        <a href="signup.php">Sign-up</a>
      </p>
    </div>
  </main>

  <footer class="main-footer">
    <div class="footer-content">
      <img src="image/logo.png" alt="Savora Logo" class="footer-logo">

      <div class="contact-info">
        <p>Email: info@Savora.com</p>
        <p>Phone: +966 50 000 0000</p>
        <p>Riyadh, Saudi Arabia</p>
      </div>
      
    </div>

    <div class="footer-bottom">&copy; 2026 Savora. All rights reserved.</div>

  </footer>
</body>
</html>
