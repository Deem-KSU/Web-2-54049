<?php

session_start();
include("db_connection.php");

if(!isset($_SESSION['user_id'])){
header("Location: login.php");
exit();
}

$userID = $_SESSION['user_id'];

$recipeID = $_POST['recipeID'];

$comment = mysqli_real_escape_string($conn,$_POST['comment']);

mysqli_query($conn,"
INSERT INTO comment(recipeID,userID,comment,date)
VALUES($recipeID,$userID,'$comment',NOW())
");

header("Location: view_recipe.php?id=$recipeID");
exit();

?>
