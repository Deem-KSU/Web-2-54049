<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SAVORA | Sign Up</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="main-header">
    <img src="image/logo.png" alt="Savora Logo" class="logo">
    <h1 class="Savora-name">SAVORA</h1>
    <a href="login.php" class="header-btn">Login</a>
  </header>

    <main class="page-content">
        <div class="auth-container">
            <h2>Create Account</h2>
            <!-- if any thing went wrong -->
            <?php if(isset($_GET['error'])) echo "<p style='color:red; text-align:center;'>".$_GET['error']."</p>"; ?>

            <form action="signup_process.php" method="POST" enctype="multipart/form-data" id="signupForm">
                <div class="input-row-flex">

                    <div class="input-group">
                        <label for="fname">First Name</label>
                    <input type="text" name="fname" id="fname" placeholder="Enter first name" required>
                    </div>

                    <div class="input-group">
                    <label for="lname">Last Name</label>
                    <input type="text"name="lname" id="lname" placeholder="Enter last name" required>
                    </div>

                </div>
                
                <div class="input-group">
                   <label for="profileImg">Profile Image (Optional)</label>
                <input type="file" id="profileImg" accept="image/*" name="profileImg">
                </div>
                
                <div class="input-group">
                  <label for="email">Email Address</label>
                  <input type="email" name="email" id="email" placeholder="example@mail.com" required>
                </div>
                
                <div class="input-group">
                  <label for="password">Password</label>

                <div class="password-wrapper">
                    <input type="password" name="password" id="password" minlength="8" placeholder="Min 8 characters" required>
                    <i class="far fa-eye" id="togglePassword"></i>
                </div>
                <p class="input-hint">Must be at least 8 characters.</p>
            </div>
            
                <button type="submit" class="primary-btn">Sign Up</button>
                <div class="form-footer">
                Already have an account? <a href="login.php">Login here</a>
            </div>
            </form>
        </div>
    </main>
    <footer class="main-footer">
    <div class="footer-content">
      <img src="image/logo.png" alt="Savora Logo" class="footer-logo">

      <div class="contact-info">
        <p>Email: info@Savora.com</p>
        <p>Phone: +966 50 000 0000</p>
        <p>Riyadh, Saudi Arabia</p>
      </div>
      
    </div>

    <div class="footer-bottom">&copy; 2026 Savora. All rights reserved.</div>

  </footer>
  <script src="script.js"></script>
</body>
</html>