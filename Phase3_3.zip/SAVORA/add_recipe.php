<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include "db_connection.php";

$error = mysqli_connect_error();

if ($error != null) {
    $output = "<p>Unable to connect to database</p>" . $error;
    exit($output);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userID =$_SESSION['user_id'];
    $name = $_POST['name'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $video_url = $_POST['video_url'];

    $ingredient_names = $_POST['ingredient_name'];
    $ingredient_qtys = $_POST['ingredient_qty'];

    $steps = $_POST['steps'];

    $photo_name = $_FILES['photo']['name'];
    $video_file_name = $_FILES['video_file']['name'];

    $video = "";

    if (!empty($video_file_name)) {
        $video = $video_file_name;
    } else if (!empty($video_url)) {
        $video = $video_url;
    }
    
    $photo_tmp = $_FILES['photo']['tmp_name'];
    move_uploaded_file($photo_tmp, "uploads/" . $photo_name);
    // becouse the video is optional
    if (!empty($video_file_name)) {
    $video = $video_file_name; 
} else if (!empty($video_url)) {
    $video = $video_url;
}
    
    $category_sql = "SELECT id FROM recipecategory WHERE categoryName = '$category'";
    $category_result = mysqli_query($conn, $category_sql);

    $category_row = mysqli_fetch_assoc($category_result);
    $category_id = $category_row['id'];
    
   $sql = "INSERT INTO recipe (userID, categoryID, name, description, photoFileName, videoFilePath)
VALUES ('$userID', '$category_id', '$name', '$description', '$photo_name', '$video')";

$result = mysqli_query($conn, $sql);
$recipe_id = mysqli_insert_id($conn);

for ($i = 0; $i < count($ingredient_names); $i++) {
        $ingredient_name = $ingredient_names[$i];
        $ingredient_qty = $ingredient_qtys[$i];

        $ingredient_sql = "INSERT INTO ingredients (recipeID, ingredientName, ingredientQuantity)
                           VALUES ('$recipe_id', '$ingredient_name', '$ingredient_qty')";

        mysqli_query($conn, $ingredient_sql);
    }
    
    for ($i = 0; $i < count($steps); $i++) {

    $step_text = $steps[$i];
    $step_order = $i + 1;

    $step_sql = "INSERT INTO instructions (recipeID, step, stepOrder)
                 VALUES ('$recipe_id', '$step_text', '$step_order')";

    mysqli_query($conn, $step_sql);
    
  }
  
  header("Location: my_recipes.php");
exit();

}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>SAVORA | Add Recipe</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styleS.css">
</head>
<body>

  <header class="main-header">
    <img src="image/logo.png" alt="Savora Logo" class="logo">

    <h1 class="Savora-name">SAVORA</h1>

     <a href="signout.php" class="header-btn">Sign Out</a>
  </header>

<main class="recipe-page">

  <section class="recipe-card">
    <h1 class="form-title">Add New Recipe</h1>
    <form action="add_recipe.php" method="POST" enctype="multipart/form-data" class="recipe-form">

      <div class="form-group">
        <label>Recipe Name</label>
        <input type="text" name="name" placeholder="Enter recipe name" required>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Category</label>
          <select name="category" required>
            <option value="" disabled selected>Select category</option>
         <?php
           $sql = "SELECT * FROM recipecategory";
           $result = mysqli_query($conn, $sql);

             while ($row = mysqli_fetch_assoc($result)) {
               echo "<option>" . $row['categoryName'] . "</option>";
               }
          ?>
          </select>
        </div>

        <div class="form-group">
          <label>Description</label>
          <textarea name="description" placeholder="Enter recipe description" required></textarea>
        </div>
      </div>
     
        <div class="form-group">
          <label>Recipe Photo</label>
          <input type="file" name="photo" accept="image/*" required>
        </div>
		
  <div class="form-group">
  <label>Ingredients</label>

  <div id="ingredients-list">
 <div class="ingredient-row">
  <span class="ingredient-num">Ingredient 1:</span>

  <div class="ingredient-inputs">
    <input type="text" name="ingredient_name[]" class="ing-name" placeholder="Name" required>
    <input type="text" name="ingredient_qty[]" class="ing-qty" placeholder="Quantity" required>
  </div>
</div>
  </div>

  <button type="button" id="add-ingredient">+ Add Ingredient</button>
</div>
		
    <div class="form-group">
  <label>Instructions</label>

  <div id="steps-list">
    <div class="step-row">
      <span class="step-num">Step 1:</span>
      <input type="text" name="steps[]" class="step-input" placeholder="Write step 1" required>
    </div>
  </div>

  <button type="button" id="add-step">+ Add Step</button>
</div>
      
      <div class="form-group">
        <label>Upload Video or URL (optional)</label>
		<input type="file" name="video_file" class="vid-file" accept="video/*">
        <input type="url" name="video_url" placeholder="URL">
        
      </div>

      <div class="form-actions">
        <button type="submit" class="submit-btn">Add Recipe</button>
      </div>

    </form>
  </section>

</main>

 <footer class="main-footer">
    <div class="footer-content">
      <img src="image/logo.png" alt="Savora Logo" class="footer-logo">

      <div class="contact-info">
        <p>Email: info@Savora.com</p>
        <p>Phone: +966 50 000 0000</p>
        <p>Riyadh, Saudi Arabia</p>
      </div>
      
    </div>

    <div class="footer-bottom">&copy; 2026 Savora. All rights reserved.</div>

  </footer>
  <script src="scriptS.js"></script>

</body>
</html>