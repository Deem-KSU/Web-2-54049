<?php

session_start();
include("db_connection.php");

$userID=$_SESSION['user_id'];
$recipeID=$_POST['recipeID'];

mysqli_query($conn,"
INSERT INTO favourites(userID,recipeID)
VALUES($userID,$recipeID)
");

header("Location: view_recipe.php?id=$recipeID");
exit();

?>