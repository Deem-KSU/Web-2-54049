<?php
session_start();
include('db_connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    //hash the password before saving it to the database
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); 
    
    // Check if the  user already exists or Blocked
    $checkEmail = "SELECT emailAddress FROM Users WHERE emailAddress='$email'"
            . "UNION SELECT emailAddress FROM BlockedUser WHERE emailAddress='$email'";
    $result = mysqli_query($conn, $checkEmail);
    
    if (!$result) {
        die("Query Failed: " . mysqli_error($conn)); 
    }

    if (mysqli_num_rows($result) > 0) {
        header("Location: signup.php?error= The Email is already exists or blocked!"); 
        exit();
    }

    $photoName = "default-account-icon.jpg"; // Set a default image
    if (!empty($_FILES['profileImg']['name'])) {
        // Create a unique name for the image using current time to avoid name conflicts
        $photoName = time() . "_" . $_FILES['profileImg']['name']; 
        //Move the photo from temp position in the server to system folder
        move_uploaded_file($_FILES['profileImg']['tmp_name'], "uploads/".$photoName);
    }

    
    $sql = "INSERT INTO Users (userType, firstName, lastName, emailAddress, password, photoFileName) 
            VALUES ('user', '$fname', '$lname', '$email', '$password', '$photoName')";
    
    //Add ID & type to session variables
    if (mysqli_query($conn, $sql)) {
        $_SESSION['user_id'] = mysqli_insert_id($conn); 
        $_SESSION['user_type'] = 'user';
        header("Location: Users.php"); 
        exit();
    } else {
        die("Error: " . mysqli_error($conn));
    }
}
?>