<?php
$servername = "localhost:8889";
$username = "root"; 
$password = "root"; 
$dbname = "savora_db"; 

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_error()) {
    die("Connection failed: " . mysqli_connect_error());
}
?>