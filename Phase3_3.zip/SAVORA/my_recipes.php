<?php
session_start();
include('db_connection.php'); 

//Check if user is not logged in or not a regular user
if(!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'user') {
    header("Location: login.php?error=Access Denied"); // kick them to login page
    exit();
}
$user_id = $_SESSION['user_id'];

//Fetch all recipes belong to this user and count total likes for each recipe
$query = "SELECT r.*, (SELECT COUNT(*) FROM Likes WHERE recipeID = r.id) as total_likes FROM Recipe r WHERE r.userID = '$user_id'";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SAVORA | My Recipes</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="main-header">
    <img src="image/logo.png" alt="Savora Logo" class="logo">
    <h1 class="Savora-name">SAVORA</h1>
    <a href="signout.php" class="header-btn">Sign Out</a>
  </header>

    <main class="page-content-wide">
        <div class="table-section">
            <div class="table-header">
                <h2>My Recipes</h2>
                <a href="add_recipe.php" class="add-recipe-link">+ Add New Recipe</a>
            </div>

            <?php if(mysqli_num_rows($result) > 0): ?> <!-- Checks if user added any recipes yet -->
            <table class="savora-table">
    <thead>
        <tr>
            <th>Recipe</th>
            <th>Ingredients</th>
            <th>Instructions</th>
            <th>Video</th>
            <th>Likes</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
   <tbody>
      <!-- Loop through each recipe and fetch it from the database -->
    <?php while($row = mysqli_fetch_assoc($result)): 
        $rid = $row['id'];
    ?>
    <tr id="recipe-row-<?php echo $rid; ?>">
        <td>
            <a href="view_recipe.php?id=<?php echo $rid; ?>" class="recipe-cell">
                <img src="uploads/<?php echo $row['photoFileName']; ?>" class="recipe-thumb">
                <span><?php echo $row['name']; ?></span>
            </a>
        </td>
        <td>
         <ul class="table-list">
        <?php 
        // Fetch and display all ingredients for recipe
        $ing_res = mysqli_query($conn, "SELECT * FROM Ingredients WHERE recipeID = '$rid'");
        while($ing = mysqli_fetch_assoc($ing_res)) {
            echo "<li>" . $ing['ingredientName']." (".$ing['ingredientQuantity'] . ")" . "</li>";
        }
        ?>
         </ul>
        </td>
        <td>
            <ol class="table-list">
                <?php 
                // Fetch and display Instructions ordered by step number
                $ins_res = mysqli_query($conn, "SELECT * FROM Instructions WHERE recipeID = '$rid' ORDER BY stepOrder ASC");
                while($ins = mysqli_fetch_assoc($ins_res)) echo "<li>".$ins['step']."</li>";
                ?>
            </ol>
        </td>
       <td>
    <?php 
    if (!empty($row['videoFilePath'])) {
        $videoPath = $row['videoFilePath'];

        if (filter_var($videoPath, FILTER_VALIDATE_URL)) {
            echo "<a href='".$videoPath."' target='_blank' class='video-link'>Watch Tutorial</a>";
        } else {
            echo "<a href='uploads/".$videoPath."' target='_blank' class='video-link'>Watch Tutorial</a>";
        }
    } else {
        echo "<span class='no-video'>no video for recipe</span>";
    }
    ?>
</td>
        <td>
            <div class="likes-count">
                <i class="fas fa-heart"></i> <?php echo $row['total_likes']; ?>
            </div>
        </td>
        <td><a href="edit_recipe.php?id=<?php echo $rid; ?>" class="action-link edit"><i class="fas fa-pen-to-square"></i></a></td>
        <td>
    <a href="javascript:void(0);" class="action-link delete" onclick="deleteRecipe(<?php echo $rid; ?>)">
        <i class="fas fa-trash-can"></i>
    </a>
</td>
    </tr>
    <?php endwhile; ?>
</tbody>
</table>
            <?php else: ?>
                <p>You do not have any recipes.</p>
            <?php endif; ?>
        </div>
    </main>
    <footer class="main-footer">
    <div class="footer-content">
      <img src="image/logo.png" alt="Savora Logo" class="footer-logo">

      <div class="contact-info">
        <p>Email: info@Savora.com</p>
        <p>Phone: +966 50 000 0000</p>
        <p>Riyadh, Saudi Arabia</p>
      </div>
      
    </div>

    <div class="footer-bottom">&copy; 2026 Savora. All rights reserved.</div>

  </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<script>
function deleteRecipe(recipeId) {
    if (confirm('Are you sure you want to delete this recipe?')) {
        $.ajax({
            url: 'delete_recipe.php',
            type: 'POST',
            data: { id: recipeId },
            success: function(response) {
                if (response.trim() === "true") {
                    $('#recipe-row-' + recipeId).fadeOut(400, function() {
                        $(this).remove();
                        if ($('.savora-table tbody tr').length === 0) {
                            $('.table-section').append('<p>You do not have any recipes!</p>');
                            $('.savora-table').remove();
                        }
                    });
                } else {
                    alert('Error: Sorry could not delete the recipe');
                }
            },
            error: function() {
                alert('Somthing went wrong!');
            }
        });
    }
}
</script>
</body>
</html>