<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SAVORA | Login</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
   <header class="main-header">
    <img src="image/logo.png" alt="Savora Logo" class="logo">
    <h1 class="Savora-name">SAVORA</h1>
    <a href="signup.php" class="header-btn">Sign Up</a>
  </header>
  

    <main class="page-content">
        <div class="auth-container">
            <h2>Login</h2>
            <!-- if any thing went wrong -->
            <?php if(isset($_GET['error'])) echo "<p style='color:red; text-align:center;'>".$_GET['error']."</p>"; ?>
            
            <form action="login_process.php" method="POST" id="loginForm">
                <div class="input-group">
                    <label for="login-email">Email Address</label>
                <input type="email" id="login-email"  name="email" placeholder="Enter your email" required>
                </div>
                
                <div class="input-group">
                  <label for="login-password">Password</label>
                  <div class="password-wrapper">
                  <input type="password" name="password" id="login-password" placeholder="Enter password" required>
                  <i class="far fa-eye" id="toggleLoginPassword" onclick="togglePass()"></i>
                </div>
                </div>
                
                <button type="submit" class="primary-btn">Log In</button>

                <div class="form-footer">
                    Don't have an account? <a href="signup.php">Create one here</a>
                </div>
            </form>
        </div>
    </main>
    <footer class="main-footer">
    <div class="footer-content">
      <img src="image/logo.png" alt="Savora Logo" class="footer-logo">

      <div class="contact-info">
        <p>Email: info@Savora.com</p>
        <p>Phone: +966 50 000 0000</p>
        <p>Riyadh, Saudi Arabia</p>
      </div>
      
    </div>

    <div class="footer-bottom">&copy; 2026 Savora. All rights reserved.</div>

  </footer>
    <script>
        function togglePass() {
            var x = document.getElementById("login-password");
            x.type = (x.type === "password") ? "text" : "password";
        }
    </script>
</body>
</html>