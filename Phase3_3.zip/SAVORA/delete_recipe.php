<?php
session_start();
include('db_connection.php');

// Check if the recipe ID is provided in the URL and the user is logged in as a user
if (isset($_POST['id']) && $_SESSION['user_type'] == 'user') {
    $recipeID = $_POST['id'];;
    $userID = $_SESSION['user_id'];

    $fileQuery = mysqli_query($conn, "SELECT photoFileName, videoFilePath FROM Recipe WHERE id='$recipeID' AND userID='$userID'");
    $files = mysqli_fetch_assoc($fileQuery);
    
    // If the recipe exists and belongs to this user
    if ($files) {
        // Delete the actual image file from the System
       if (file_exists("uploads/" . $files['photoFileName'])) {
            unlink("uploads/" . $files['photoFileName']);
        }
        if ($files['videoFilePath'] && file_exists("uploads/" . $files['videoFilePath'])) {
            unlink("uploads/" . $files['videoFilePath']);
        }
        // Delete the recipe from the database. 
        // Related info will be deleted automatically due to the CASCADE constraint 
    if (mysqli_query($conn, "DELETE FROM Recipe WHERE id='$recipeID'")) {
            echo "true"; 
        } else {
            echo "false";
        }
    } else {
        echo "false";
    }
    exit;
}
?>