<?php
session_start();
include('db_connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']); // clean the email before use it to prevent SQL injection! 
    $password = $_POST['password'];

    //Check if the user is Blocked
    $checkBlocked = mysqli_query($conn, "SELECT id FROM BlockedUser WHERE emailAddress='$email'");
    if (mysqli_num_rows($checkBlocked) > 0) {
        header("Location: login.php?error=This account is blocked!"); 
        exit();
    }

    $result = mysqli_query($conn, "SELECT * FROM users WHERE emailAddress='$email'");
    $user = mysqli_fetch_assoc($result);
    
    // Verify if user exists and the password matches the hashed password in DB and set session varible
    if ($user && password_verify($password, $user['password'])) { 
        $_SESSION['user_id'] = $user['id']; 
        $_SESSION['user_type'] = $user['userType']; 

        
        if ($user['userType'] == 'admin') {
            header("Location: admins.php"); 
        } else {
            header("Location: Users.php"); 
        }
      // If credentials don't match display an error message and redirect to login page
    } else {
        header("Location: login.php?error=Invalid email or password!"); 
    }
}
?>