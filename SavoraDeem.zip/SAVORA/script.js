function setupToggle(iconId, inputId) {
    const icon = document.getElementById(iconId);
    const input = document.getElementById(inputId);
    if (icon && input) {
        icon.addEventListener('click', function() {
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
            this.classList.toggle('fa-eye-slash');
        });
    }
}

setupToggle('togglePassword', 'password');
setupToggle('toggleLoginPassword', 'login-password');

function validateForm(e) {
    const pass = document.getElementById('password').value;
    const email = document.getElementById('email').value;

    if (pass.length < 8) {
        alert("Password must be at least 8 characters!");
        e.preventDefault();
        return false;
    }
    
    if (email && !email.includes('@')) {
        document.getElementById('email').value = email + "@gmail.com";
        alert("Email auto-completed with @gmail.com");
    }
    return true;
}